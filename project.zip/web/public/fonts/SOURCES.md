Manrope Variable: https://github.com/google/fonts/blob/main/ofl/manrope/Manrope%5Bwght%5D.ttf
Cormorant Garamond Regular / Italic, version 4.000: https://github.com/google/fonts/tree/6a386aadc0a33dd3d810b833d9c5105345cbb0e6/ofl/cormorantgaramond

Both families include Czech characters and are distributed with the adjacent SIL Open Font License files. The CI build produces WOFF2 subsets from these local originals for the public web.
