import { defineConfig } from 'astro/config';
export default defineConfig({output:'static',base:'/vorlovka/',site:'https://emperorkundis.github.io',devToolbar:{enabled:false}});
