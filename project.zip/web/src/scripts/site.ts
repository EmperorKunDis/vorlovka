// JavaScript-compatible TypeScript for both Astro and the offline export.
(() => {
 const select = (s: string): any => document.querySelector(s);
 const all = (s: string): any[] => [...document.querySelectorAll(s)];
 const cards = all('.piece');
 const buttons = all('[data-filter]');
 const more = select('#load-more');
 const count = select('#gallery-count');
 let active = 'Všechno'; let limit = 12;
 function update() {
  const matched = cards.filter(c => active === 'Všechno' || c.getAttribute('data-category') === active);
  cards.forEach(c => c.hidden = !matched.includes(c) || matched.indexOf(c) >= limit);
  more.hidden = matched.length <= limit;
  count.textContent = `Zobrazeno ${Math.min(limit, matched.length)} / ${matched.length} ukázek tvorby`;
  if (window.ScrollTrigger) requestAnimationFrame(() => window.ScrollTrigger.refresh());
 }
 buttons.forEach(b => b.addEventListener('click', () => {
  active = b.getAttribute('data-filter'); limit = 12;
  buttons.forEach(x => x.setAttribute('aria-pressed', String(x === b))); update();
 }));
 more.addEventListener('click', () => { const previous=limit; limit += 12; update(); const matched = cards.filter(c => !c.hidden); matched[previous]?.querySelector('button')?.focus({preventScroll:true}); });
 update();
 const dialog = select('#lightbox');
 const full = select('#lightbox-image'); let opener;
 all('[data-photo]').forEach(b => b.addEventListener('click', () => {
  opener=b; full.src=`images/${b.getAttribute('data-photo')}-1200.webp`; full.alt=b.getAttribute('data-title');
  select('#lightbox-title').textContent=b.getAttribute('data-title');
  select('#original-post').href=b.getAttribute('data-post'); dialog.showModal();
 }));
 dialog.querySelector('.close').addEventListener('click', () => dialog.close());
 dialog.addEventListener('click', e => { if (e.target === dialog) { const r=dialog.getBoundingClientRect(); if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)dialog.close(); } });
 dialog.addEventListener('close', () => { full.removeAttribute('src'); opener?.focus({preventScroll:true}); });
 if (window.gsap && window.ScrollTrigger) {
  const gsap=window.gsap;
  gsap.registerPlugin(window.ScrollTrigger);
  gsap.matchMedia().add('(prefers-reduced-motion: no-preference)', () => {
   const mobile=window.matchMedia('(max-width:650px)').matches;
   const strength=mobile ? .32 : 1;
   // One scene-wide timeline: foreground, products, copy and atmosphere separate in depth.
   const scene=gsap.timeline({scrollTrigger:{trigger:'.hero',start:'top top',end:'bottom top',scrub:.7},defaults:{ease:'none'}});
   scene.to('.hero-halo',{y:190*strength,scale:1.22},0)
    .to('.hero-copy',{y:-115*strength},0)
    .to('.hero-main',{y:-260*strength,x:65*strength,rotation:-5,scale:1.08},0)
    .to('.hero-small',{y:-125*strength,x:-65*strength,rotation:1,scale:1.16},0)
    .to('.handwritten',{y:-180*strength,x:35*strength,rotation:5},0)
    .to('.flower-0',{y:-90*strength,x:90*strength,rotation:42,scale:1.12},0)
    .to('.flower-1',{y:-460*strength,x:-115*strength,rotation:-54,scale:1.25},0)
    .to('.flower-2',{y:-310*strength,x:-40*strength,rotation:8,scale:1.16},0)
    .to('.flower-3',{y:110*strength,x:35*strength,rotation:160,scale:.88},0);
   // A persistent, viewport-wide garden lives OUTSIDE all sections.
   // Its timeline spans the entire document, so the same flowers cross section boundaries.
   const garden=gsap.timeline({scrollTrigger:{trigger:document.documentElement,start:'top top',end:()=>window.ScrollTrigger.maxScroll(window),scrub:1.1,invalidateOnRefresh:true},defaults:{ease:'none'}});
   garden.fromTo('.global-bloom-0',{y:-160*strength,rotation:-18,scale:.88},{keyframes:[{y:180*strength,rotation:8,scale:1.05},{y:-70*strength,rotation:-10,scale:.96},{y:300*strength,rotation:16,scale:1.12},{y:20*strength,rotation:-7,scale:1}],duration:1},0);
   garden.fromTo('.global-bloom-1',{y:180*strength,rotation:24,scale:1.1},{keyframes:[{y:-220*strength,rotation:-5,scale:.95},{y:60*strength,rotation:19,scale:1.06},{y:-280*strength,rotation:-12,scale:.9},{y:-80*strength,rotation:7,scale:1}],duration:1},0);
   garden.fromTo('.global-bloom-2',{y:80*strength,rotation:36,scale:.9},{keyframes:[{y:-90*strength,rotation:14,scale:1.1},{y:190*strength,rotation:42,scale:.98},{y:-130*strength,rotation:9,scale:1.04},{y:110*strength,rotation:28,scale:.93}],duration:1},0);
   garden.fromTo('.global-bloom-3',{y:-120*strength,rotation:-32,scale:.94},{keyframes:[{y:100*strength,rotation:-12,scale:1.08},{y:-180*strength,rotation:-38,scale:.9},{y:70*strength,rotation:-4,scale:1.1},{y:-100*strength,rotation:-22,scale:1}],duration:1},0);
   garden.to('.garden-atmosphere',{xPercent:12,yPercent:-12,rotation:9,scale:1.2,duration:1},0);
   // The quieter scenes continue the same depth language throughout the page.
   gsap.fromTo('.world-visual figure',{y:65*strength,rotation:-5},{y:-65*strength,rotation:1,ease:'none',scrollTrigger:{trigger:'.world',start:'top bottom',end:'bottom top',scrub:1}});
   gsap.fromTo('.circle-label',{y:-40*strength,rotation:-7},{y:75*strength,rotation:18,ease:'none',scrollTrigger:{trigger:'.world',start:'top bottom',end:'bottom top',scrub:.7}});
   all('.detail-grid figure').forEach((el,i)=>gsap.fromTo(el,{y:(i===1?65:-30)*strength},{y:(i===1?-65:30)*strength,ease:'none',scrollTrigger:{trigger:'.details',start:'top bottom',end:'bottom top',scrub:1}}));
   gsap.fromTo('.request-flower',{y:90*strength,rotation:35},{y:-110*strength,rotation:60,ease:'none',scrollTrigger:{trigger:'.request',start:'top bottom',end:'bottom top',scrub:1}});
   gsap.fromTo('.contact>img',{y:90*strength,rotation:-12},{y:-90*strength,rotation:-32,ease:'none',scrollTrigger:{trigger:'.contact',start:'top bottom',end:'bottom top',scrub:1}});
  });
 }
})();
